package com.example.akash.intents;

import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;
import android.widget.Toast;

public class subActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        Bundle data =getIntent().getExtras();
        if(data==null)
        {
            return;
        }
        String message = data.getString("message");
        final TextView tv2 = (TextView)findViewById(R.id.tv2);
        tv2.setText("Hello "+message+" ..!");
        Toast.makeText(this, "WELCOME", Toast.LENGTH_LONG).show();
   }

}
